# ربات جنریتور API HASH , API ID تلگرام
# نسخه اصلاح‌شده - امن و بدون باگ تغییر نام دکمه

import asyncio
import html
import json
import logging
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, Tuple

from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from telegram.ext import (
    Application, CommandHandler, MessageHandler, filters,
    ContextTypes, ConversationHandler
)
from bs4 import BeautifulSoup
import aiohttp

# -------------------------------
# تنظیمات اولیه و لاگینگ
# -------------------------------
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# -------------------------------
# توکن ربات و آیدی عددی ادمین (مستقیم)
# -------------------------------
BOT_TOKEN = "8967252277:AAE8-kEJaCRja2cIMQyYsFsKsBzUrW8nEgk"
ADMIN_ID = 8051932673

# -------------------------------
# فایل‌های ذخیره‌سازی
# -------------------------------
DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)
USERS_FILE = DATA_DIR / "users.json"
CONFIG_FILE = DATA_DIR / "config.json"

# تنظیم دسترسی فایل‌ها به فقط مالک
os.chmod(DATA_DIR, 0o700)
for f in [USERS_FILE, CONFIG_FILE]:
    if f.exists():
        os.chmod(f, 0o600)

# -------------------------------
# تنظیمات پیش‌فرض
# -------------------------------
DEFAULT_CONFIG = {
    "bot_enabled": True,
    "force_join": {
        "enabled": False,
        "channel_username": "",
        "verify_text": "🔒 برای استفاده از ربات ابتدا در کانال ما عضو شوید:",
        "join_button_text": "🚀 عضویت در کانال",
        "check_button_text": "✅ عضو شدم"
    },
    "support": {
        "username": None,
        "text": "🆘 برای پشتیبانی با ما در ارتباط باشید:"
    },
    "texts": {
        "start": "🌟 <b>ربات ساخت API تلگرام</b> 🌟\n\n"
                 "برای ساخت API جدید روی دکمه زیر کلیک کنید:",
        "help": "📖 <b>راهنمای استفاده از ربات</b>\n\n"
                "1️⃣ روی دکمه <b>دریافت API</b> کلیک کنید\n"
                "2️⃣ شماره تلگرام خود را وارد کنید\n"
                "3️⃣ کد وبی را که از تلگرام می‌آید وارد کنید\n"
                "4️⃣ API ID و Hash شما نمایش داده می‌شود\n\n"
                "🔒 تمام اطلاعات از سایت رسمی my.telegram.org دریافت می‌شود",
        "my_accounts_empty": "👀 <b>اینجا چیزی نیست خالیه!</b>\n"
                            "هنوز هیچ APIای نساخته‌اید. روی «دریافت API» بزنید.",
        "bot_disabled": "😴 ربات در حال استراحت است. بعداً مراجعه کنید.",
        "phone_prompt": "📞 <b>لطفاً شماره تلگرام خود را وارد کنید:</b>\n\n"
                       "مثال: <code>+989123456789</code>\n"
                       "برای لغو، روی /cancel بزنید.",
        "code_prompt": "🔐 <b>کد وبی را که از تلگرام آمده وارد کنید:</b>",
        "already_has_api": "🔁 شما قبلاً API ساخته‌اید.\n"
                           "آیا می‌خواهید API جدید بسازید؟",
    },
    "buttons": {
        "main": [
            ["👤 اکانت‌های من", "🚀 دریافت API"],
            ["🆘 پشتیبانی", "ℹ️ راهنما"]
        ]
    }
}

# -------------------------------
# بارگذاری / ذخیره تنظیمات و کاربران
# -------------------------------
def load_config() -> Dict[str, Any]:
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                config = json.load(f)
            for key, value in DEFAULT_CONFIG.items():
                if key not in config:
                    config[key] = value
            return config
        except:
            return DEFAULT_CONFIG.copy()
    else:
        config = DEFAULT_CONFIG.copy()
        save_config(config)
        return config

def save_config(config: Dict[str, Any]):
    temp_file = CONFIG_FILE.with_suffix('.tmp')
    with open(temp_file, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=4)
    temp_file.replace(CONFIG_FILE)
    os.chmod(CONFIG_FILE, 0o600)

def load_users() -> Dict[str, Any]:
    if USERS_FILE.exists():
        try:
            with open(USERS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            return {}
    else:
        return {}

def save_users(users: Dict[str, Any]):
    temp_file = USERS_FILE.with_suffix('.tmp')
    with open(temp_file, "w", encoding="utf-8") as f:
        json.dump(users, f, ensure_ascii=False, indent=4)
    temp_file.replace(USERS_FILE)
    os.chmod(USERS_FILE, 0o600)

# -------------------------------
# کلاس ساخت API
# -------------------------------
class WebAPICreator:
    def __init__(self, phone: str):
        self.phone = phone
        self.base_url = "https://my.telegram.org"
        self.session = None

    async def send_code_request(self):
        try:
            self.session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=30),
                headers={'User-Agent': 'Mozilla/5.0'}
            )
            send_data = {'phone': self.phone}
            async with self.session.post(
                f"{self.base_url}/auth/send_password",
                data=send_data
            ) as response:
                response_text = await response.text()
                if response.status != 200:
                    return False, f"خطا در ارسال درخواست: {response.status}"
                random_hash = self._extract_random_hash(response_text)
                if not random_hash:
                    return False, "خطا در دریافت random_hash"
                return True, random_hash
        except Exception as e:
            return False, f"خطا: {str(e)}"

    async def login_with_web_code(self, random_hash: str, web_code: str):
        try:
            login_data = {
                'phone': self.phone,
                'random_hash': random_hash,
                'password': web_code
            }
            async with self.session.post(
                f"{self.base_url}/auth/login",
                data=login_data
            ) as login_response:
                if login_response.status != 200:
                    return False, "کد وب نامعتبر است"
                cookies = self.session.cookie_jar.filter_cookies(self.base_url)
                if not any('stel_token' in str(c) for c in cookies):
                    return False, "لاگین ناموفق"
                return True, "لاگین موفق"
        except Exception as e:
            return False, f"خطا در لاگین: {str(e)}"

    async def get_or_create_api(self):
        try:
            async with self.session.get(f"{self.base_url}/apps") as apps_response:
                if apps_response.status != 200:
                    return None, "خطا در دریافت صفحه apps"
                response_text = await apps_response.text()
                soup = BeautifulSoup(response_text, 'html.parser')
                existing_api = self._extract_existing_api(soup)
                if existing_api:
                    return existing_api, None
                hash_value = self._extract_hash(soup)
                if not hash_value:
                    return None, "خطا در دریافت hash"
                timestamp = str(int(datetime.now().timestamp()))
                create_data = {
                    'hash': hash_value,
                    'app_title': f'App_{timestamp}',
                    'app_shortname': f'app{timestamp}',
                    'app_url': '',
                    'app_platform': 'other',
                    'app_desc': 'My Application'
                }
                async with self.session.post(
                    f"{self.base_url}/apps/create",
                    data=create_data
                ) as create_response:
                    if create_response.status not in [200, 302]:
                        return None, "خطا در ساخت API"

            async with self.session.get(f"{self.base_url}/apps") as final_response:
                response_text = await final_response.text()
                api_data = self._extract_api_from_page(response_text)
                if not api_data:
                    return None, "خطا در استخراج API"
                return api_data, None
        except Exception as e:
            return None, f"خطا: {str(e)}"

    async def close(self):
        if self.session and not self.session.closed:
            await self.session.close()

    def _extract_random_hash(self, html_text):
        match = re.search(r'random_hash["\']?\s*[:=]\s*["\']([a-f0-9]+)', html_text)
        return match.group(1) if match else None

    def _extract_hash(self, soup):
        hash_input = soup.find('input', {'name': 'hash'})
        return hash_input.get('value') if hash_input else None

    def _extract_existing_api(self, soup):
        spans = soup.find_all('span', class_='form-control input-xlarge uneditable-input')
        if len(spans) >= 2:
            api_id = spans[0].get_text(strip=True)
            api_hash = spans[1].get_text(strip=True)
            if api_id.isdigit() and len(api_hash) == 32:
                return (api_id, api_hash)
        return None

    def _extract_api_from_page(self, html_text):
        id_match = re.search(r'api_id["\']?\s*[:=]\s*["\']?(\d+)', html_text, re.IGNORECASE)
        hash_match = re.search(r'api_hash["\']?\s*[:=]\s*["\']?([a-f0-9]{32})', html_text, re.IGNORECASE)
        if id_match and hash_match:
            return (id_match.group(1), hash_match.group(1))
        return None

# -------------------------------
# توابع کمکی
# -------------------------------
def get_user_api(user_id: int) -> Optional[Tuple[str, str]]:
    users = load_users()
    user_data = users.get(str(user_id), {})
    if "api_id" in user_data and "api_hash" in user_data:
        return user_data["api_id"], user_data["api_hash"]
    return None

def save_user_api(user_id: int, phone: str, api_id: str, api_hash: str):
    users = load_users()
    users[str(user_id)] = {
        "phone": phone,
        "api_id": api_id,
        "api_hash": api_hash,
        "created_at": datetime.now().isoformat()
    }
    save_users(users)

def is_admin(user_id: int) -> bool:
    return user_id == ADMIN_ID

def build_main_keyboard(user_id: int) -> ReplyKeyboardMarkup:
    config = load_config()
    keyboard = []
    for row in config["buttons"]["main"]:
        keyboard.append([KeyboardButton(text) for text in row])
    if is_admin(user_id):
        keyboard.append([KeyboardButton("🔧 پنل مدیریت")])
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

async def check_force_join(user_id: int, context: ContextTypes.DEFAULT_TYPE) -> bool:
    config = load_config()
    if not config["force_join"]["enabled"]:
        return True
    channel_username = config["force_join"]["channel_username"]
    if not channel_username:
        return True
    try:
        member = await context.bot.get_chat_member(chat_id=f"@{channel_username}", user_id=user_id)
        return member.status in ["member", "administrator", "creator"]
    except Exception as e:
        logger.error(f"خطا در بررسی عضویت: {e}")
        return False

# -------------------------------
# استیت‌های مختلف
# -------------------------------
WAITING_PHONE, WAITING_WEB_CODE, WAITING_NEW_API_CONFIRM = range(3)
ADMIN_WAITING_TEXT = 3

user_states = {}

# -------------------------------
# هندلرهای منو
# -------------------------------
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    config = load_config()
    if not config["bot_enabled"]:
        await update.message.reply_text(config["texts"]["bot_disabled"])
        return
    if not await check_force_join(update.effective_user.id, context):
        await show_force_join(update, context)
        return
    await update.message.reply_text(
        config["texts"]["start"],
        reply_markup=build_main_keyboard(update.effective_user.id),
        parse_mode='HTML'
    )

async def show_force_join(update: Update, context: ContextTypes.DEFAULT_TYPE):
    config = load_config()
    channel_username = config["force_join"]["channel_username"]
    keyboard = [
        [KeyboardButton(config["force_join"]["join_button_text"])],
        [KeyboardButton(config["force_join"]["check_button_text"])]
    ]
    await update.message.reply_text(
        config["force_join"]["verify_text"],
        reply_markup=ReplyKeyboardMarkup(keyboard, resize_keyboard=True),
        parse_mode='HTML'
    )

async def my_accounts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    api = get_user_api(user_id)
    config = load_config()
    if api:
        api_id, api_hash = api
        text = (
            f"👤 <b>اکانت شما:</b>\n\n"
            f"🔑 API ID: <code>{html.escape(api_id)}</code>\n"
            f"🔐 API Hash: <code>{html.escape(api_hash)}</code>\n\n"
            f"می‌توانید API جدید بسازید."
        )
    else:
        text = config["texts"]["my_accounts_empty"]
    await update.message.reply_text(
        text,
        reply_markup=build_main_keyboard(user_id),
        parse_mode='HTML'
    )

async def support(update: Update, context: ContextTypes.DEFAULT_TYPE):
    config = load_config()
    support_username = config["support"].get("username")
    if support_username:
        text = config["support"]["text"] + f"\n\n@{html.escape(support_username)}"
    else:
        text = config["support"]["text"]
    await update.message.reply_text(
        text,
        reply_markup=build_main_keyboard(update.effective_user.id),
        parse_mode='HTML'
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    config = load_config()
    await update.message.reply_text(
        config["texts"]["help"],
        reply_markup=build_main_keyboard(update.effective_user.id),
        parse_mode='HTML'
    )

# -------------------------------
# هندلر دریافت API (با کیبورد زیرین)
# -------------------------------
async def generate_api(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    config = load_config()
    if not config["bot_enabled"]:
        await update.message.reply_text(config["texts"]["bot_disabled"])
        return ConversationHandler.END
    if get_user_api(user_id):
        keyboard = [
            [KeyboardButton("✅ بله، API جدید بساز")],
            [KeyboardButton("❌ انصراف")]
        ]
        await update.message.reply_text(
            config["texts"]["already_has_api"],
            reply_markup=ReplyKeyboardMarkup(keyboard, one_time_keyboard=True, resize_keyboard=True)
        )
        user_states[user_id] = {"step": WAITING_NEW_API_CONFIRM}
        return WAITING_NEW_API_CONFIRM

    await update.message.reply_text(
        config["texts"]["phone_prompt"],
        reply_markup=ReplyKeyboardRemove(),
        parse_mode='HTML'
    )
    user_states[user_id] = {"step": WAITING_PHONE}
    return WAITING_PHONE

async def confirm_new_api(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    config = load_config()
    text = update.message.text.strip()
    if text == "✅ بله، API جدید بساز":
        await update.message.reply_text(
            config["texts"]["phone_prompt"],
            reply_markup=ReplyKeyboardRemove(),
            parse_mode='HTML'
        )
        user_states[user_id] = {"step": WAITING_PHONE}
        return WAITING_PHONE
    elif text == "❌ انصراف":
        await update.message.reply_text(
            "✅ عملیات لغو شد",
            reply_markup=build_main_keyboard(user_id)
        )
        return ConversationHandler.END
    else:
        await update.message.reply_text("لطفاً یکی از گزینه‌ها را انتخاب کنید.")
        return WAITING_NEW_API_CONFIRM

async def handle_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    config = load_config()
    text = update.message.text.strip()
    if text == "❌ انصراف":
        await cancel_command(update, context)
        return ConversationHandler.END

    phone = re.sub(r'[^\d+]', '', text)
    if not re.match(r'^\+?[1-9]\d{7,14}$', phone):
        await update.message.reply_text(
            "❌ شماره نامعتبر است! لطفاً دوباره وارد کنید:",
            reply_markup=ReplyKeyboardRemove()
        )
        return WAITING_PHONE
    if not phone.startswith('+'):
        phone = '+' + phone

    creator = WebAPICreator(phone)
    user_states[user_id] = {
        "step": WAITING_WEB_CODE,
        "phone": phone,
        "creator": creator
    }
    loading_msg = await update.message.reply_text("⏳ در حال ارسال درخواست کد...")
    success, result = await creator.send_code_request()
    if not success:
        await loading_msg.edit_text(
            f"❌ خطا: {html.escape(result)}\n\n"
            f"برای تلاش مجدد روی /start بزنید."
        )
        await creator.close()
        del user_states[user_id]
        return ConversationHandler.END
    user_states[user_id]["random_hash"] = result
    await loading_msg.edit_text(
        f"✅ درخواست کد ارسال شد!\n\n"
        f"📱 شماره: <code>{html.escape(phone)}</code>\n\n"
        f"{config['texts']['code_prompt']}",
        parse_mode='HTML'
    )
    return WAITING_WEB_CODE

async def handle_web_code(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in user_states:
        await update.message.reply_text("❌ لطفاً عملیات را مجدداً شروع کنید.")
        return ConversationHandler.END
    text = update.message.text.strip()
    if text == "❌ انصراف":
        await cancel_command(update, context)
        return ConversationHandler.END

    state = user_states[user_id]
    web_code = text
    phone = state["phone"]
    creator = state["creator"]
    random_hash = state["random_hash"]
    loading_msg = await update.message.reply_text("⏳ در حال بررسی کد وب...")
    success, login_result = await creator.login_with_web_code(random_hash, web_code)
    if not success:
        await loading_msg.edit_text(f"❌ خطا در لاگین: {html.escape(login_result)}")
        await creator.close()
        del user_states[user_id]
        return ConversationHandler.END
    await loading_msg.edit_text("✅ لاگین موفق! در حال دریافت API...")
    api_data, error = await creator.get_or_create_api()
    if error:
        await loading_msg.edit_text(f"❌ خطا: {html.escape(error)}")
        await creator.close()
        del user_states[user_id]
        return ConversationHandler.END
    if api_data:
        api_id, api_hash = api_data
        save_user_api(user_id, phone, api_id, api_hash)
        text = (
            f"🎉 API ساخته شد!\n\n"
            f"📱 شماره: <code>{html.escape(phone)}</code>\n"
            f"🔑 API ID: <code>{html.escape(api_id)}</code>\n"
            f"🔐 API Hash: <code>{html.escape(api_hash)}</code>"
        )
        await loading_msg.edit_text(text, parse_mode='HTML')
    else:
        await loading_msg.edit_text("❌ خطا در دریافت API")
    await creator.close()
    del user_states[user_id]
    await update.message.reply_text(
        "برای بازگشت به منو روی /start بزنید.",
        reply_markup=build_main_keyboard(user_id)
    )
    return ConversationHandler.END

async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id in user_states:
        state = user_states[user_id]
        if 'creator' in state:
            await state['creator'].close()
        del user_states[user_id]
    await update.message.reply_text(
        "✅ عملیات لغو شد",
        reply_markup=build_main_keyboard(user_id)
    )
    return ConversationHandler.END

# -------------------------------
# پنل مدیریتی (بدون تغییر نام دکمه‌ها)
# -------------------------------
def build_admin_keyboard():
    keyboard = [
        [KeyboardButton("📊 آمار ربات")],
        [KeyboardButton("💤 خاموش/روشن")],
        [KeyboardButton("📝 تنظیم متن‌ها")],
        [KeyboardButton("🆘 تنظیم پشتیبانی")],
        [KeyboardButton("🔒 جوین اجباری")],
        [KeyboardButton("🔙 بازگشت به منو")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text("⛔️ دسترسی غیرمجاز")
        return
    config = load_config()
    await update.message.reply_text(
        "🔧 <b>پنل مدیریت</b>\n\n"
        f"وضعیت ربات: {'✅ فعال' if config['bot_enabled'] else '❌ غیرفعال'}\n"
        f"تعداد کاربران: {len(load_users())}",
        reply_markup=build_admin_keyboard(),
        parse_mode='HTML'
    )

async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    users = load_users()
    total_users = len(users)
    total_apis = sum(1 for u in users.values() if 'api_id' in u)
    text = f"📊 <b>آمار ربات</b>\n\n"
    text += f"👥 کاربران کل: {total_users}\n"
    text += f"🔑 APIهای ساخته‌شده: {total_apis}\n"
    text += f"⏰ زمان حال: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    await update.message.reply_text(text, parse_mode='HTML', reply_markup=build_admin_keyboard())

async def admin_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    config = load_config()
    config["bot_enabled"] = not config["bot_enabled"]
    save_config(config)
    status = "✅ فعال" if config["bot_enabled"] else "❌ غیرفعال"
    await update.message.reply_text(
        f"وضعیت ربات تغییر کرد: {status}",
        reply_markup=build_admin_keyboard()
    )

async def admin_texts_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    keyboard = [
        [KeyboardButton("📝 متن شروع")],
        [KeyboardButton("📝 متن راهنما")],
        [KeyboardButton("📝 متن اکانت خالی")],
        [KeyboardButton("🔙 بازگشت")]
    ]
    await update.message.reply_text(
        "کدام متن را می‌خواهید ویرایش کنید؟",
        reply_markup=ReplyKeyboardMarkup(keyboard, one_time_keyboard=True, resize_keyboard=True)
    )

async def edit_text_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END
    context.user_data["admin_edit"] = "start"
    await update.message.reply_text("متن جدید برای پیام شروع را ارسال کنید:", reply_markup=ReplyKeyboardRemove())
    return ADMIN_WAITING_TEXT

async def edit_text_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END
    context.user_data["admin_edit"] = "help"
    await update.message.reply_text("متن جدید برای راهنما را ارسال کنید:", reply_markup=ReplyKeyboardRemove())
    return ADMIN_WAITING_TEXT

async def edit_text_empty(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END
    context.user_data["admin_edit"] = "my_accounts_empty"
    await update.message.reply_text("متن جدید برای لیست خالی اکانت‌ها را ارسال کنید:", reply_markup=ReplyKeyboardRemove())
    return ADMIN_WAITING_TEXT

async def receive_admin_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END
    text = update.message.text.strip()
    if text == "🔙 بازگشت":
        await back_to_admin(update, context)
        return ConversationHandler.END

    edit_key = context.user_data.get("admin_edit")
    if not edit_key:
        return ConversationHandler.END
    config = load_config()
    if edit_key in config["texts"]:
        config["texts"][edit_key] = text
    elif edit_key == "support_text":
        config["support"]["text"] = text
    elif edit_key == "support_username":
        config["support"]["username"] = text
    elif edit_key == "force_channel":
        config["force_join"]["channel_username"] = text
    save_config(config)
    await update.message.reply_text(
        "✅ متن با موفقیت ذخیره شد.",
        reply_markup=build_admin_keyboard()
    )
    context.user_data.pop("admin_edit", None)
    return ConversationHandler.END

async def admin_support_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    keyboard = [
        [KeyboardButton("🆘 تنظیم متن پشتیبانی")],
        [KeyboardButton("👤 تنظیم یوزرنیم پشتیبان")],
        [KeyboardButton("🔙 بازگشت")]
    ]
    await update.message.reply_text(
        "تنظیمات پشتیبانی:",
        reply_markup=ReplyKeyboardMarkup(keyboard, one_time_keyboard=True, resize_keyboard=True)
    )

async def edit_support_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END
    context.user_data["admin_edit"] = "support_text"
    await update.message.reply_text("متن جدید پشتیبانی را ارسال کنید:", reply_markup=ReplyKeyboardRemove())
    return ADMIN_WAITING_TEXT

async def edit_support_username(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END
    context.user_data["admin_edit"] = "support_username"
    await update.message.reply_text("یوزرنیم پشتیبان (بدون @) را ارسال کنید:", reply_markup=ReplyKeyboardRemove())
    return ADMIN_WAITING_TEXT

async def admin_force_join_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    config = load_config()
    status = "فعال ✅" if config["force_join"]["enabled"] else "غیرفعال ❌"
    keyboard = [
        [KeyboardButton(f"تغییر وضعیت (اکنون {status})")],
        [KeyboardButton("تنظیم آیدی کانال")],
        [KeyboardButton("🔙 بازگشت")]
    ]
    await update.message.reply_text(
        "تنظیمات جوین اجباری:",
        reply_markup=ReplyKeyboardMarkup(keyboard, one_time_keyboard=True, resize_keyboard=True)
    )

async def toggle_force_join(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    config = load_config()
    config["force_join"]["enabled"] = not config["force_join"]["enabled"]
    save_config(config)
    await admin_force_join_menu(update, context)

async def set_force_channel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END
    context.user_data["admin_edit"] = "force_channel"
    await update.message.reply_text("آیدی کانال/گروه (بدون @) را ارسال کنید:", reply_markup=ReplyKeyboardRemove())
    return ADMIN_WAITING_TEXT

# -------------------------------
# بازگشت‌ها
# -------------------------------
async def back_to_main(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "بازگشت به منوی اصلی",
        reply_markup=build_main_keyboard(update.effective_user.id)
    )

async def back_to_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    await update.message.reply_text(
        "بازگشت به پنل مدیریت",
        reply_markup=build_admin_keyboard()
    )

# -------------------------------
# هندلر خطا
# -------------------------------
async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    logger.error(f"خطا رخ داد: {context.error}")
    if update and update.effective_user:
        user_id = update.effective_user.id
        if user_id in user_states:
            state = user_states[user_id]
            if 'creator' in state:
                await state['creator'].close()
            del user_states[user_id]

# -------------------------------
# تابع اصلی
# -------------------------------
def main():
    application = Application.builder().token(BOT_TOKEN).build()

    # ConversationHandler برای دریافت API
    conv_handler = ConversationHandler(
        entry_points=[
            MessageHandler(filters.Regex(r'^🚀 دریافت API$'), generate_api),
            MessageHandler(filters.Regex(r'^✅ بله، API جدید بساز$'), confirm_new_api),
            MessageHandler(filters.Regex(r'^❌ انصراف$'), cancel_command),
        ],
        states={
            WAITING_PHONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_phone)],
            WAITING_WEB_CODE: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_web_code)],
            WAITING_NEW_API_CONFIRM: [MessageHandler(filters.TEXT & ~filters.COMMAND, confirm_new_api)],
        },
        fallbacks=[CommandHandler('cancel', cancel_command)]
    )

    # ConversationHandler برای تنظیمات ادمین (فقط متن‌ها، بدون تغییر دکمه)
    admin_conv_handler = ConversationHandler(
        entry_points=[
            MessageHandler(filters.Regex(r'^📝 متن شروع$'), edit_text_start),
            MessageHandler(filters.Regex(r'^📝 متن راهنما$'), edit_text_help),
            MessageHandler(filters.Regex(r'^📝 متن اکانت خالی$'), edit_text_empty),
            MessageHandler(filters.Regex(r'^🆘 تنظیم متن پشتیبانی$'), edit_support_text),
            MessageHandler(filters.Regex(r'^👤 تنظیم یوزرنیم پشتیبان$'), edit_support_username),
            MessageHandler(filters.Regex(r'^تنظیم آیدی کانال$'), set_force_channel),
        ],
        states={
            ADMIN_WAITING_TEXT: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_admin_text)],
        },
        fallbacks=[CommandHandler('cancel', cancel_command)]
    )

    # هندلرهای دکمه‌های منو
    application.add_handler(CommandHandler('start', start_command))
    application.add_handler(conv_handler)
    application.add_handler(admin_conv_handler)

    # هندلرهای دکمه‌های کیبوردی
    application.add_handler(MessageHandler(filters.Regex(r'^👤 اکانت‌های من$'), my_accounts))
    application.add_handler(MessageHandler(filters.Regex(r'^🆘 پشتیبانی$'), support))
    application.add_handler(MessageHandler(filters.Regex(r'^ℹ️ راهنما$'), help_command))
    application.add_handler(MessageHandler(filters.Regex(r'^🔧 پنل مدیریت$'), admin_panel))
    application.add_handler(MessageHandler(filters.Regex(r'^📊 آمار ربات$'), admin_stats))
    application.add_handler(MessageHandler(filters.Regex(r'^💤 خاموش/روشن$'), admin_toggle))
    application.add_handler(MessageHandler(filters.Regex(r'^📝 تنظیم متن‌ها$'), admin_texts_menu))
    application.add_handler(MessageHandler(filters.Regex(r'^🆘 تنظیم پشتیبانی$'), admin_support_menu))
    application.add_handler(MessageHandler(filters.Regex(r'^🔒 جوین اجباری$'), admin_force_join_menu))
    application.add_handler(MessageHandler(filters.Regex(r'^🔙 بازگشت به منو$'), back_to_main))
    application.add_handler(MessageHandler(filters.Regex(r'^🔙 بازگشت$'), back_to_admin))
    application.add_handler(MessageHandler(filters.Regex(r'^تغییر وضعیت .*$'), toggle_force_join))

    application.add_error_handler(error_handler)

    print("🤖 ربات فعال شد...")
    application.run_polling()

if __name__ == "__main__":
    main()